INTERNAL MARKS CALCULATOR - SIMPLE VERSION

Folder structure:
Internal_Marks_Calculator_Simple/
    marks_pkg/
        __init__.py
        ActualTask.py
    main.py

Weightage:
Test 1 = 30%
Test 2 = 30%
Assignment = 40%
Pass mark = 40

Run from this folder:
python main.py

Sample test 1:
80, 70, 90 -> Total 81, Grade B, Pass

Sample test 2:
40, 40, 40 -> Total 40, Grade E, Pass

Sample test 3:
110, 70, 80 -> Invalid marks message
